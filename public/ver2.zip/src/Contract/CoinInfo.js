export const CoinAddress = '0x65254Be8519e97DB783d0FfDE6646E104c5277a5';
export const CoinOwnerWallet = '0x8ddEb68dDa25B11b0a187E1366b65D21f3b5C5d8';