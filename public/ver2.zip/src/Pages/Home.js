import classes from "./Page.module.css";
const Home = () => {

    return (
        <div className={classes.summary}>
            <h2> Landing Page</h2>
            <p>Home Page</p>
        </div>
        
    )

}

export default Home;